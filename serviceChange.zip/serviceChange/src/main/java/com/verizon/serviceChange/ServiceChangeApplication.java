package com.verizon.serviceChange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceChangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceChangeApplication.class, args);
	}

}
